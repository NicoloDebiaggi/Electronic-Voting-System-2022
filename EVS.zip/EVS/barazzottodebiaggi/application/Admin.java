package application;

public class Admin extends Utente {

}
