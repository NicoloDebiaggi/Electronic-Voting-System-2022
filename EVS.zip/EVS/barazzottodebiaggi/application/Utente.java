package application;

public abstract class Utente {

}
