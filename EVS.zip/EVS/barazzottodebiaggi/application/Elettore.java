package application;

public class Elettore extends Utente {

}
