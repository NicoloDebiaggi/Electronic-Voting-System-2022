package application;

public class AdminDAO {
	public Admin effettuaLogin(String usr, String psw) {
		Admin a = new Admin();
		return a;
	}
	public void effettuaRegistrazione(String usr, String psw) {
		
	}
	public boolean checkCf(String cf) {
		
		return true;
	}
}
