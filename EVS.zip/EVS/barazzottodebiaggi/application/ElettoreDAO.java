package application;

public class ElettoreDAO {
	public Elettore effettuaLogin(String usr, String psw) {
		Elettore e = new Elettore();
		return e;
	}
	public void effettuaRegistrazione(String usr, String psw) {
		
	}
	public boolean checkCf(String cf) {
		
		return true;
	}
}
